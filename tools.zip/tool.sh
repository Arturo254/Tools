#!bin/bash/
apt update -y
apt upgrade -y
pkg update -y
pkg upgrade -y
rm -rf Tools.zip
