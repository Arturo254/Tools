Ejecutar Tool.sh al Descomprimir Tools.zip

visita mi github: https://github.com/Arturo254
